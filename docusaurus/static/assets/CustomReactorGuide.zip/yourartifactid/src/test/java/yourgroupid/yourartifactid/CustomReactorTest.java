package yourgroupid.yourartifactid;

import yourgroupid.yourartifactid.reactor.CustomReactor;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

import prerna.sablecc2.om.GenRowStruct;
import prerna.sablecc2.om.PixelDataType;
import prerna.sablecc2.om.nounmeta.NounMetadata;

public class CustomReactorTest {

    final static String NAME_INPUT_STRING = "name"; 
    
    @Test
    public void myTest() {
        // Set up a test reactor
        CustomReactor myCustomReactor = new CustomReactor();
		myCustomReactor.In();

        // Add test input to the reactor
        String inputName = "YOUR_NAME";
		GenRowStruct input = new GenRowStruct();
		input.add(new NounMetadata(inputName, PixelDataType.CONST_STRING));
		myCustomReactor.getNounStore().addNoun(NAME_INPUT_STRING, input);

        // Call the reactor (this invokes the overridden execute() method defined in CustomReactor.java)
		NounMetadata reactorOutput = myCustomReactor.execute();

        // Parse the output from the reactor
        String actualString = (String) reactorOutput.getValue();

        // Compare if the expected result (Hello YOUR_NAME!) matches the actual reactor output
        String expectedString = "Hello   " + inputName + "!";
        assertEquals(expectedString, actualString);
    }
	
    // Convenience main method
    // public static void main() {
    //    CustomReactorTest test = new CustomReactorTest();
    //    test.myTest();
    // }
     
}