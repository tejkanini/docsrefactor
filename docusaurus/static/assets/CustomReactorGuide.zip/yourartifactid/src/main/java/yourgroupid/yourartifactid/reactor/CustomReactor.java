package yourgroupid.yourartifactid.reactor;

import prerna.sablecc2.reactor.AbstractReactor;
import prerna.sablecc2.om.PixelDataType;
import prerna.sablecc2.om.nounmeta.NounMetadata;


public class CustomReactor extends AbstractReactor {

    final static String NAME_INPUT_STRING = "name"; 

    public CustomReactor() {
        // define what input arguments the reactor should receive
        this.keysToGet = new String[] { NAME_INPUT_STRING };
    }

	@Override
	public NounMetadata execute() {
        // parse the user inputs into a 'keyValue' map
        organizeKeys();

        // get the value that corresponds to the "name" input from the 'keyValue' map
        String userName = this.keyValue.get(NAME_INPUT_STRING);

        // output a message using the name obtained from the user input
        String message = "Hello " + userName + "!";
		return new NounMetadata(message, PixelDataType.CONST_STRING);
	}
}